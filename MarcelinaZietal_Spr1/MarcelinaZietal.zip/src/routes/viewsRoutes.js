const express = require('express');
const router = express.Router();
const indexController = require('../controllers/indexController')

router.get('', (req,res) => indexController.mainPage(req,res))

module.exports = router