exports.mainPage = async function(req, res) {
    res.render('index');
}