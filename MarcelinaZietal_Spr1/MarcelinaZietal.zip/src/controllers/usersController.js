const passport = require('passport');
const User = require('../utils/db');
const { SHA3 } = require("sha3");
const hash = new SHA3(256);

exports.resetUsers = function(req, res, next) {
  User.deleteMany({}, function (err) {
    if (err) return handleError(err);
    hash.reset();
    var admin = new User({ "username":"admin", "password":hash.update("stud234").digest('hex') });
    hash.reset();
    var asdf = new User({ "username":"asdf", "password":hash.update("asdf").digest('hex') });
    // create two users: 'admin' and 'asdf'
    admin.save( function(err,data) {
      if (err) return console.error(err);
      asdf.save( function(err,data2) {
        if (err) return console.error(err);
        res.render('reset', { data: data, data2: data2} );
      })
    });
  });
}


exports.getUsers = function(req, res) {
  User.find(function (err, data) {
    if (err) return console.error(err);
    console.log(data);
    res.json(data);
  })
}


exports.loginUser = passport.authenticate('local',
  {
    session: true,
    successRedirect: '/',
    failureRedirect: '/login'
  }
)


exports.logoutUser = function(req, res, next){
  req.logout(function(err) {
    if (err) { return next(err); }
    res.redirect('/');
  });
  // res.redirect('/');
}
