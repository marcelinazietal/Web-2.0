const Laptop = require('../models/laptops')

const getAllLaptops = async (req, res) => {
    try {
        const laptops = await Laptop.find();
        res.render("laptops", {
            laptops:laptops
        });
    } catch (error) {
        res.status(400).json({error: error.message})
    }
};

const getLaptopById = async (req, res) => {
    try {
        const {id} = req.params;
        const laptop = await Laptop.findById(id);

        if(laptop){
            return res.status(404).json({message: "Laptop not found"});
        }
        res.json(laptop);
    } catch (error) {
        res.status(400).json({error: error.message})
    }
};

//create
const createLaptop = async (req, res) => {
    try {
        const {
            processor,
            ram,
            max_ram,
            ram_slots,
            ssd,
            additional_drives,
            touchscreen,
            screen_type,
            screen_size,
            screen_resolution,
            refresh_rate,
            graphics_card,
            integrated_graphics,
            graphics_memory,
            sound,
            built_in_speakers,
            built_in_microphones,
            webcam,
            connectivity,
            usb_ports,
            hdmi_ports,
            lan_port,
            audio_jack,
            dc_in,
            dominant_color,
            fingerprint_reader,
            backlit_keyboard,
            keyboard_backlight_color,
            security,
            operating_system,
            power_adapter,
            additional_info,
            height,
            width,
            depth,
            weight,
            included_accessories,
            warranty_type,
            warranty_duration,
            manufacturer_code
        } = req.body;

        const laptop = await Laptop.create({
            processor,
            ram,
            max_ram,
            ram_slots,
            ssd,
            additional_drives,
            touchscreen,
            screen_type,
            screen_size,
            screen_resolution,
            refresh_rate,
            graphics_card,
            integrated_graphics,
            graphics_memory,
            sound,
            built_in_speakers,
            built_in_microphones,
            webcam,
            connectivity,
            usb_ports,
            hdmi_ports,
            lan_port,
            audio_jack,
            dc_in,
            dominant_color,
            fingerprint_reader,
            backlit_keyboard,
            keyboard_backlight_color,
            security,
            operating_system,
            power_adapter,
            additional_info,
            height,
            width,
            depth,
            weight,
            included_accessories,
            warranty_type,
            warranty_duration,
            manufacturer_code
        });

        res.redirect('/');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

//update
const updateLaptop = async (req, res) => {
    try {
        const {
            processor,
            ram,
            max_ram,
            ram_slots,
            ssd,
            additional_drives,
            touchscreen,
            screen_type,
            screen_size,
            screen_resolution,
            refresh_rate,
            graphics_card,
            integrated_graphics,
            graphics_memory,
            sound,
            built_in_speakers,
            built_in_microphones,
            webcam,
            connectivity,
            usb_ports,
            hdmi_ports,
            lan_port,
            audio_jack,
            dc_in,
            dominant_color,
            fingerprint_reader,
            backlit_keyboard,
            keyboard_backlight_color,
            security,
            operating_system,
            power_adapter,
            additional_info,
            height,
            width,
            depth,
            weight,
            included_accessories,
            warranty_type,
            warranty_duration,
            manufacturer_code
        } = req.body;

        const laptopId = req.params.id;

        const updatedLaptop = await Laptop.findByIdAndUpdate(laptopId, {
            processor,
            ram,
            max_ram,
            ram_slots,
            ssd,
            additional_drives,
            touchscreen,
            screen_type,
            screen_size,
            screen_resolution,
            refresh_rate,
            graphics_card,
            integrated_graphics,
            graphics_memory,
            sound,
            built_in_speakers,
            built_in_microphones,
            webcam,
            connectivity,
            usb_ports,
            hdmi_ports,
            lan_port,
            audio_jack,
            dc_in,
            dominant_color,
            fingerprint_reader,
            backlit_keyboard,
            keyboard_backlight_color,
            security,
            operating_system,
            power_adapter,
            additional_info,
            height,
            width,
            depth,
            weight,
            included_accessories,
            warranty_type,
            warranty_duration,
            manufacturer_code
        });

        res.redirect('/');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

//delete
const deleteLaptop = async (req, res) => {
    try {
        const laptopId = req.params.id;
        await Laptop.findByIdAndDelete(laptopId);
        res.redirect('/');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

module.exports = {
    getAllLaptops,
    getLaptopById,
    createLaptop,
    updateLaptop,
    deleteLaptop
}