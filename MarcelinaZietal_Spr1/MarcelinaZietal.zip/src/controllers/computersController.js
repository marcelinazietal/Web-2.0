const Computer = require('../models/computers')

const getAllComputers = async (req, res) => {
    try {
        const computers = await Computer.find();
        res.render("computers", {
            computers:computers
        });
    } catch (error) {
        res.status(400).json({error: error.message})
    }
};

const getComputerById = async (req, res) => {
    try {
        const {id} = req.params;
        const computer = await Computer.findById(id);

        if(computer){
            return res.status(404).json({message: "Computer not found"});
        }
        res.json(computer);
    } catch (error) {
        res.status(400).json({error: error.message})
    }
};

//create
const createComputer = async (req, res) => {
    try {
        const {
            processor,
            chipset,
            ram,
            max_ram,
            ram_slots,
            graphics_card,
            graphics_memory,
            ssd,
            additional_drives,
            optical_drives,
            sound,
            connectivity,
            front_panel_ports,
            rear_panel_ports,
            internal_ports,
            power_supply,
            case_lighting,
            lighting_modes,
            additional_features,
            included_accessories,
            operating_system,
            height,
            width,
            depth,
            weight,
            warranty_duration,
            warranty_type,
            manufacturer_code
        } = req.body;

        const computer = await Computer.create({
            processor,
            chipset,
            ram,
            max_ram,
            ram_slots,
            graphics_card,
            graphics_memory,
            ssd,
            additional_drives,
            optical_drives,
            sound,
            connectivity,
            front_panel_ports,
            rear_panel_ports,
            internal_ports,
            power_supply,
            case_lighting,
            lighting_modes,
            additional_features,
            included_accessories,
            operating_system,
            height,
            width,
            depth,
            weight,
            warranty_duration,
            warranty_type,
            manufacturer_code
        });

        res.redirect('/');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

//update
const updateComputer = async (req, res) => {
    try {
        const {
            processor,
            chipset,
            ram,
            max_ram,
            ram_slots,
            graphics_card,
            graphics_memory,
            ssd,
            additional_drives,
            optical_drives,
            sound,
            connectivity,
            front_panel_ports,
            rear_panel_ports,
            internal_ports,
            power_supply,
            case_lighting,
            lighting_modes,
            additional_features,
            included_accessories,
            operating_system,
            height,
            width,
            depth,
            weight,
            warranty_duration,
            warranty_type,
            manufacturer_code
        } = req.body;

        const computerId = req.params.id;

        const updatedComputer = await Computer.findByIdAndUpdate(computerId, {
            processor,
            chipset,
            ram,
            max_ram,
            ram_slots,
            graphics_card,
            graphics_memory,
            ssd,
            additional_drives,
            optical_drives,
            sound,
            connectivity,
            front_panel_ports,
            rear_panel_ports,
            internal_ports,
            power_supply,
            case_lighting,
            lighting_modes,
            additional_features,
            included_accessories,
            operating_system,
            height,
            width,
            depth,
            weight,
            warranty_duration,
            warranty_type,
            manufacturer_code
        });

        res.redirect('/');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

//delete
const deleteComputer = async (req, res) => {
    try {
        const computerId = req.params.id;
        await Computer.findByIdAndDelete(computerId);
        res.redirect('/');
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

module.exports = {
    getAllComputers,
    getComputerById,
    createComputer
}