const db = require('../utils/db');

const computerSchema = new db.Schema({
    processor: { type: String },
    chipset: { type: String },
    ram: { type: String },
    max_ram: { type: String },
    ram_slots: { type: String },
    graphics_card: { type: String },
    graphics_memory: { type: String },
    ssd: { type: String },
    additional_drives: { type: String },
    optical_drives: { type: String },
    sound: { type: String },
    connectivity: { type: String },
    front_panel_ports: { type: String },
    rear_panel_ports: { type: String },
    internal_ports: { type: String },
    power_supply: { type: String },
    case_lighting: { type: String },
    lighting_modes: { type: String },
    additional_features: { type: String },
    included_accessories: { type: String },
    operating_system: { type: String },
    height: { type: String },
    width: { type: String },
    depth: { type: String },
    weight: { type: String },
    warranty_duration: { type: String },
    warranty_type: { type: String },
    manufacturer_code: { type: String }
});

const ComputerModel = db.model("computers", computerSchema);

module.exports = ComputerModel;
