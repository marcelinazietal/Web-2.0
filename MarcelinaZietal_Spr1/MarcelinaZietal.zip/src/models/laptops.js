const db = require('../utils/db');

const laptopSchema = new db.Schema({
    processor: { type: String },
    ram: { type: String },
    max_ram: { type: String },
    ram_slots: { type: String },
    ssd: { type: String },
    additional_drives: { type: String },
    touchscreen: { type: Boolean },
    screen_type: { type: String },
    screen_size: { type: String },
    screen_resolution: { type: String },
    refresh_rate: { type: String },
    graphics_card: { type: String },
    integrated_graphics: { type: String },
    graphics_memory: { type: String },
    sound: { type: String },
    built_in_speakers: { type: String },
    built_in_microphones: { type: String },
    webcam: { type: String },
    connectivity: { type: String },
    usb_ports: { type: String },
    hdmi_ports: { type: String },
    lan_port: { type: String },
    audio_jack: { type: String },
    dc_in: { type: String },
    dominant_color: { type: String },
    fingerprint_reader: { type: Boolean },
    backlit_keyboard: { type: Boolean },
    keyboard_backlight_color: { type: String },
    security: { type: String },
    operating_system: { type: String },
    power_adapter: { type: String },
    additional_info: { type: String },
    height: { type: String },
    width: { type: String },
    depth: { type: String },
    weight: { type: String },
    included_accessories: { type: String },
    warranty_type: { type: String },
    warranty_duration: { type: String },
    manufacturer_code: { type: String }
});

const LaptopModel = db.model("laptops", laptopSchema);

module.exports = LaptopModel;
